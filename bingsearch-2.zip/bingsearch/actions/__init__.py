"""测试插件动作模块"""

# 导入所有动作模块以确保装饰器被执行
from . import bing_search  # noqa